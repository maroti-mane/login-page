package com.teluskoSe.SpringSecurityS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecuritySApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecuritySApplication.class, args);
	}

}
